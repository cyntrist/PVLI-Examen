export default class Container extends Phaser.GameObjects.Container {
    constructor(scene, x, y) {
        super(scene, x, y);
    }

    create() {

    }

    update() {
        
    }
}