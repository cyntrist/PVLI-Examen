/*
function newGatoCosmico(x, y, ropa, nombre){
	let gato = {};
	gato.nombre = nombre;
	gato.x = x;
	gato.y = y;
	gato.outfit = ropa;
	gato.inventario = [];
	gato.arma = null;
	gato.dispararBesitos = besitos;
	gato.dispararRatones = ratoncitos;
	
	return gato
}*/

function newGatoCosmico(x, y, ropa, nombre){
	this.nombre = nombre;
	this.x = x;
	this.y = y;
	this.outfit = ropa;
	this.inventario = [];
	this.arma = null;
	this.dispararBesitos = besitos;
	this.dispararRatones = ratoncitos;
}

let besitos = function(){
	console.log(this.nombre+" te ha dado un <3")
}
	
let ratoncitos = function(){
	console.log("Explotas!! de parte de", this.nombre)
}
	
let Jerry = new newGatoCosmico(0, 0, "Sombrero de Vaquero", "Jerry");
let Jordi = new newGatoCosmico(100, 100, "Túnica de mago", "Jordi");

console.log(Jerry);
console.log(Jordi);
console.log(Jerry.dispararBesitos === Jordi.dispararBesitos);
Jerry.dispararBesitos();
Jordi.dispararRatones();
