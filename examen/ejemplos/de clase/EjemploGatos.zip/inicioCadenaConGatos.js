let gato = {
	nombre : "sin nombre",
	x : 0,
	y : 0,
	moverse: function(){
		this.x += 10;
	}
}

let gatoConBotas = Object.create(gato);
gatoConBotas.nombre = "Tom";
gatoConBotas.outfit = "guantes";
gatoConBotas.moverse = function(){
	this.x += 100;
}

let gatoCosmico = Object.create(gatoConBotas);