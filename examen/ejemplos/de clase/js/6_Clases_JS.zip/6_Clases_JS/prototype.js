/*
	Los comentarios con /** * / contienen documentacion JSdoc
	Permiten crear una web con documentación
	más info en https://jsdoc.app/
*/

/**
 * Clase que representa una posición
 * @class
 */
function Position(x, y){
	this.x = x;
	this.y = y;
}

/**
 * Clase que representa una nave
 * @class
 * @augments Ship
 */
function Ship(position, graphic){
	this._position = position;
	this._graphic = graphic;
};
Ship.prototype.moveLeft = function(){
	this._position.x-=2;
};
Ship.prototype.moveRight = function(){
	this._position.x+=2;
};

/**
 * Clase que representa un enemigo, hereda de Ship
 * @class
 * @augments Ship
 */
function Enemy(position, graphic, score){
	Ship.apply(this, [position, graphic]);
	this._currentDirection = 'right';
	this._score = score;
}
Enemy.prototype = Object.create(Ship.prototype);
Enemy.prototype.constructor = Enemy;
Enemy.prototype.advance = function () {
  this._position.y += 2;
};

/**
 * Clase que representa al jugador, hereda de Ship
 * @class
 * @augments Ship
 */
function Ally(position){
	Ship.apply(this, [position, "ally.png"]);
}
Ally.prototype = Object.create(Ship.prototype);
Ally.prototype.constructor = Ally;



//Instanciación de objetos
let me = new Ally(new Position(0,0));
let enemy = new Enemy(new Position(100, 100), "enemy1.png", 666);
let myShip = new Ship(new Position(50,50), "myShip2.png")

/*
console.log("info",
	Enemy.constructor === Ship.constructor,
	Object.getPrototypeOf(me) === Ally.prototype,
	Object.getPrototypeOf(enemy) === Enemy.prototype,
	Ally.prototype !== Enemy.prototype,
	Object.getPrototypeOf(Ally.prototype) === Object.getPrototypeOf(Enemy.prototype),
	Object.getPrototypeOf(Ally.prototype) === Ship.prototype,
	Object.getPrototypeOf(me),
	'\n','\n',
	"_score:", enemy.hasOwnProperty('_score'), '\n',
	"advance", enemy.hasOwnProperty('advance'), '\n',
	"moveLeft", enemy.hasOwnProperty('moveLeft'), '\n',
	"instancia enemy", enemy,
	'\n','\n',
	"_score:", Enemy.prototype.hasOwnProperty('_score'), '\n',
	"advance", Enemy.prototype.hasOwnProperty('advance'), '\n',
	"moveLeft", Enemy.prototype.hasOwnProperty('moveLeft'), '\n',
	"'clase' enemy", Enemy.prototype,
	'\n','\n',
	"_score:", Ship.prototype.hasOwnProperty('_score'), '\n',
	"advance", Ship.prototype.hasOwnProperty('advance'), '\n',
	"moveLeft", Ship.prototype.hasOwnProperty('moveLeft'), '\n',
	"'clase' ship",Ship.prototype,
	'\n','\n',
	'enemy instancia de Enemy', enemy instanceof Enemy, '\n',  // el primer eslabón
	'enemy instancia de Ship', enemy instanceof Ship, '\n',   // el segundo
	'enemy instancia de Object', enemy instanceof Object, '\n', // el tercero
	'enemy instancia de Ally', enemy instanceof Ally, '\n',
    '\n', '\n',
	enemy,
	'\n',
	Enemy
)
*/