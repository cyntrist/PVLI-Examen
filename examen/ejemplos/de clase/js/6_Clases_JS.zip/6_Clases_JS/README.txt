En JS no existen las clases aunque tengamos las palabras "class" y "extends",
es tan solo "azucarillo sintáctico", JS por debajo lo pasa a cadenas de prototype
puedes ejecutar ambos ejemplo de esta carpeta y mostrar las instancias de los objetos
con tu navegador, verás que ambos generan lo mismo y el navegador muestra cadenas de <prototype>