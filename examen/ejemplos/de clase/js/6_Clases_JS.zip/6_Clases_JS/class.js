/*
	Los comentarios con /** * / contienen documentacion JSdoc
	Permiten crear una web con documentación
	más info en https://jsdoc.app/
*/

/**
 * Clase que representa una posición
 */
class Position{
	/**
	 * Crea una posición
	 * @param {number} x - El valor de la coordenada X.
	 * @param {number} y - El valor de la coordenada Y.
	 */
	constructor(x, y){
		this.x = x;
		this.y = y;
	}
}

/**
 * Clase que representa una nave
 * @extends Ship
 */
class Ship{
	/**
	 * Crea una nave
	 * @param {Position} position - La posición de la nave.
	 * @param {string} graphic - imagen que representa a la nave.
	 */
	constructor(position, graphic){
		this._position = position;
		this._graphic = graphic;
	}
	
	/**
	 * Mueve la nave a la izquierda
	 */
	moveLeft(){
		this._position.x-=2;
	}
	
	/**
	 * Mueve la nave a la derecha
	 */
	moveRight(){
		this._position.x+=2;
	}
};

/**
 * Clase que representa un enemigo, hereda de Ship
 * @extends Ship
 */
class Enemy extends Ship{
	/**
	 * Crea un enemigo
	 * @param {Position} position - La posición de la nave.
	 * @param {string} graphic - imagen que representa a la nave.
	 * @param {number} score - puntos que da al derrotarlo.
	 */
	constructor(position, graphic, score){
		super(position, graphic); //llamamos al contructor padre, es decir al contructor de Ship para obtener sus parámetros)
		this._currentDirection = 'right';
		this._score = score;
	}
	
	/**
	 * Mueve la nave hacia adelante
	 */
	advance(){
		this._position.y += 2;
	}
}

/**
 * Clase que representa al jugador, hereda de Ship
 * @extends Ship
 */
class Ally extends Ship{
	/**
	 * Crea una nave de jugador
	 * @param {Position} position - La posición de la nave.
	 */
	constructor(position){
		super(position, "ally.png") //llamamos al contructor padre, es decir al contructor de Ship para obtener sus parámetros)
	}
}



//Instanciación de objetos
let me = new Ally(new Position(0,0));
let enemy = new Enemy(new Position(100, 100), "enemy1.png", 666);
let myShip = new Ship(new Position(50,50), "myShip2.png")

/*
console.log("info",
	Enemy.constructor === Ship.constructor,
	Object.getPrototypeOf(me) === Ally.prototype,
	Object.getPrototypeOf(enemy) === Enemy.prototype,
	Ally.prototype !== Enemy.prototype,
	Object.getPrototypeOf(Ally.prototype) === Object.getPrototypeOf(Enemy.prototype),
	Object.getPrototypeOf(Ally.prototype) === Ship.prototype,
	Object.getPrototypeOf(me),
	'\n','\n',
	"_score:", enemy.hasOwnProperty('_score'), '\n',
	"advance", enemy.hasOwnProperty('advance'), '\n',
	"moveLeft", enemy.hasOwnProperty('moveLeft'), '\n',
	"instancia enemy", enemy,
	'\n','\n',
	"_score:", Enemy.prototype.hasOwnProperty('_score'), '\n',
	"advance", Enemy.prototype.hasOwnProperty('advance'), '\n',
	"moveLeft", Enemy.prototype.hasOwnProperty('moveLeft'), '\n',
	"'clase' enemy", Enemy.prototype,
	'\n','\n',
	"_score:", Ship.prototype.hasOwnProperty('_score'), '\n',
	"advance", Ship.prototype.hasOwnProperty('advance'), '\n',
	"moveLeft", Ship.prototype.hasOwnProperty('moveLeft'), '\n',
	"'clase' ship",Ship.prototype,
	'\n','\n',
	'enemy instancia de Enemy', enemy instanceof Enemy, '\n',  // el primer eslabón
	'enemy instancia de Ship', enemy instanceof Ship, '\n',   // el segundo
	'enemy instancia de Object', enemy instanceof Object, '\n', // el tercero
	'enemy instancia de Ally', enemy instanceof Ally, '\n',
    '\n', '\n',
	enemy,
	'\n',
	Enemy
)
*/