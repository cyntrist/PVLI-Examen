// Aproximemonos más a las clases
// Cambiamos nuestra función que crea una nave para que use un objeto Position
function Position(x, y){
	this.x = x;
	this.y = y;
}

// Vamos a diferenciar "atributos" de "métodos"
// "_" normalmente indica que un atributo es "privado"
// En js nada es privado
function Ship(position, graphic){
	this._position = position;
	this._graphic = graphic;
};

// Usamos la propiedad "prototype" de las funciones para crear los métodos del objeto, 
// de esta forma el objeto instanciado también obtendrá estos métodos
Ship.prototype.moveLeft = function(){
	this._position.x-=2;
};

Ship.prototype.moveRight = function(){
	this._position.x+=2;
};

let myShip = new Ship(new Position(50,50), "myShip2.png")

// Muestra la nave antes y después de hacer moveLeft() o usar otro método

// console.log("prototype de Ship:", Ship.prototype)

// Lo siguientes es crear la herencia
