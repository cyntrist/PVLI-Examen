// Antes de crear herencia primero es necesario entender el comportamiento de 
// la palabra "new" y de las funciones que no devuelven nada

console.log(typeof Object) 

console.log(new Object)

/*
	El "new" de una función devuelve un objeto
*/
function Nada(){
}

let o = new Nada
console.log(o)

/*
	Si dentro de la funcion hacemos this.<algo>, cuando usemos new, nos devolverá el objeto con esa propiedad
	Más info de new: https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Operators/new
*/
function Algo(){
	this.miPropiedad = 5
}

let a = new Algo
console.log(a)

//.prototype es un atributo propio tanto de Function como de Object (en Object es oculto)
console.log("prototype", Algo.prototype)