/*
	Función para crear un objeto Posición
	Contiene 2 propiedades
		- x - coordenada X
		- y - coordenada Y
*/
function Position(x, y){
	this.x = x;
	this.y = y;
}

/*
	Función y uso de prototype para crear un objeto Ship
	Objeto "ship" con 2 propiedades (position, graphic) y 2 métodos (moveLeft y moveRight)
*/
function Ship(position, graphic){
	this._position = position;
	this._graphic = graphic;
};
Ship.prototype.moveLeft = function(){
	this._position.x-=2;
};
Ship.prototype.moveRight = function(){
	this._position.x+=2;
};

/*
	Función y uso de prototype para crear un objeto Enemy
	Queremos que Enemy herede de Ship, es decir, obtener sus mismas propiedades y métodos
*/
function Enemy(position, graphic, score){
	Ship.apply(this, [position, graphic]); //llamamos a la función Ship con nuestro this
	this._currentDirection = 'right';
	this._score = score;
}
Enemy.prototype.advance = function () {
  this._position.y += 2;
};

/*
	Función y uso de prototype para crear un objeto Ally
*/
function Ally(position){
	Ship.apply(this, [position, "ally.png"]); //llamamos a la función Ship con nuestro this
} 

let normalShip = new Ship(new Position(50,50), "myShip2.png")
let me = new Ally(new Position(0,0));
let enemy = new Enemy(new Position(100, 100), "enemy1.png", 666);

// Muestra las naves
// Prueba a mover las naves con los métodos moveLeft, moveRight y advance


// ¿Problema?
// Vemos que nuestros objetos "enemy" y "ally" tienen las propiedades _position y _graphic de "Ship" pero no sus métodos



/*
console.log("info",
	Enemy.constructor === Ship.constructor,
	Object.getPrototypeOf(me) === Ally.prototype,
	Object.getPrototypeOf(enemy) === Enemy.prototype,
	Ally.prototype !== Enemy.prototype,
	Object.getPrototypeOf(Ally.prototype) === Object.getPrototypeOf(Enemy.prototype),
	Object.getPrototypeOf(Ally.prototype) === Ship.prototype,
	Object.getPrototypeOf(me),
	'\n','\n',
	"_score:", enemy.hasOwnProperty('_score'), '\n',
	"advance", enemy.hasOwnProperty('advance'), '\n',
	"moveLeft", enemy.hasOwnProperty('moveLeft'), '\n',
	"instancia enemy", enemy,
	'\n','\n',
	"_score:", Enemy.prototype.hasOwnProperty('_score'), '\n',
	"advance", Enemy.prototype.hasOwnProperty('advance'), '\n',
	"moveLeft", Enemy.prototype.hasOwnProperty('moveLeft'), '\n',
	"'clase' enemy", Enemy.prototype,
	'\n','\n',
	"_score:", Ship.prototype.hasOwnProperty('_score'), '\n',
	"advance", Ship.prototype.hasOwnProperty('advance'), '\n',
	"moveLeft", Ship.prototype.hasOwnProperty('moveLeft'), '\n',
	"'clase' ship",Ship.prototype,
	'\n','\n',
	'instancia de Enemy', enemy instanceof Enemy, '\n',  // el primer eslabón
	'instancia de Ship', enemy instanceof Ship, '\n',   // el segundo
	'instancia de Object', enemy instanceof Object, '\n', // el tercero
	'instancia de Ally', enemy instanceof Ally, '\n',
    '\n', '\n',
	enemy,
	'\n',
	Enemy
)
*/