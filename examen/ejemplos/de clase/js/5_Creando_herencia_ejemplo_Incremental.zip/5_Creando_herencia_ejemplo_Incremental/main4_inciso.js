// Inciso -- ¿Cómo conseguir que te explote la cabeza?
//                            ||
//                            ||
//                          \VVVV/
//                           \VV/
//                            \/
// Juguemos con objetos, funciones que devuelven funciones, self y this

function newShip(position, graphic, mL, mR){
	return {
		position: {
			x:position[0], 
			y:position[1]
		},
		graphic: graphic,
		moveLeft: mL.move(),
		moveRight: mR.move(),
	};
};

let bigLeftMove = {
	movement:80,
	move: function(){
		let self = this;
		return function(){this.position.x-=self.movement};
	}
}

let bigRightMove = {
	movement:80,
	move: function(){
		let self = this;
		return function(){this.position.x+=self.movement};
	}
}

let smallLeftMove = {
	movement:5,
	move: function(){
		let self = this;
		return function(){this.position.x-=self.movement};
	}
}

let smallRightMove = {
	movement:5,
	move: function(){
		let self = this;
		return function(){this.position.x+=self.movement};
	}
}

let bigShip = newShip([0,100], "BIG.png", bigLeftMove, bigRightMove)
let smallShip = newShip([0, 0], "small.png", smallLeftMove, smallRightMove)

/*
console.log("bigShip", bigShip)
console.log("movemos bigShip")
bigShip.moveLeft()
console.log("bigShip", bigShip)

console.log("______")

console.log("smallShip", smallShip)
console.log("movemos smallShip")
smallShip.moveRight()
console.log("smallShip", smallShip)

console.log("_____")
*/

