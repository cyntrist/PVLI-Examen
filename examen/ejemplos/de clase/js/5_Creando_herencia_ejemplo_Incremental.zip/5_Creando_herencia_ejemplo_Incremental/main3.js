//Podemos hacer que los métodos moveLeft y moveRight sean funciones creadas fuera del objeto
function newShip(position, graphic){
	return {
		position: {
			x:position[0], 
			y:position[1]
		},
		graphic: graphic,
		moveLeft: moveLeftFunct,
		moveRight: moveRightFunct
	};
};

//this dependerá del objeto que las llama (objeto que recibe el mensaje)
function moveLeftFunct(){
	this.position.x-=2;
};

function moveRightFunct(){
	this.position.x+=2;
};

// Creamos los objetos
let myShip = newShip([50,50], "myShip2.png")
let ship2 = newShip([100, 100], "otherShip.png")

// Mostramos "myShip" antes y después de utilizar el método "moveLeft()"


// ¿Los métodos myShip.moveLeft y ship2.moveLeft son el mismo?


// Lo siguiente, ¿cómo hacemos herencia?

