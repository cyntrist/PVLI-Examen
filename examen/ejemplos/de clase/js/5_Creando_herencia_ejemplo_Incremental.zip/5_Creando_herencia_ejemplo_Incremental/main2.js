/*
	Podemos crear una función que devuelva un nuevo objeto con valores
	que dependan de los recibidos como atributos de la función 

	Ahora, la función newShip devuelve un objeto "ship" con 2 propiedades (position, graphic) y 2 métodos (moveLeft y moveRight)
*/
function newShip(position, graphic){
	return {
		position: {
			x:position[0], 
			y:position[1]
		},
		graphic: graphic,
		moveLeft: function() {this.position.x-=2},
		moveRight: function() {this.position.x+=2}
	};
}

//Creamos 2 nuevos objetos con "position" y "graphics" diferentes
let myShip = newShip([0,0], "myShip.png")
let ship2 = newShip([100, 100], "otherShip.png")

//Mostramos los objetos "myShip" y "ship2"

//¿Son iguales el método moveLeft de ambos objetos?

//¿Problemas?
//los métodos de ambos objetos son distintos, ocupamos "mucha" más memoria por cada objeto creado
