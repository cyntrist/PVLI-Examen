Esto es un ejemplo incremental para entender como podemos generar funciones que nos devuelvan objetos
imitando la funcionalidad de Instancia, Clases y Herencia de otros lenguajes como Java y C#.
Así podremos programar nuestros juegos usando orientación a objetos.

Iremos desde main1.js hasta main10.js modificando el script hasta llegar al resultado final.