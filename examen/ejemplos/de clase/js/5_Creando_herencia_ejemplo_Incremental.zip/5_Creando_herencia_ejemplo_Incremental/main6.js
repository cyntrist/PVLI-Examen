// Creamos nuestra función que nos devolvera un objeto cuando hagamos new
function Ship(position, graphic){
	this.position = {
			x:position[0], 
			y:position[1]
	};
	this.graphic = graphic;
	this.moveLeft = moveLeftFunct;
	this.moveRight = moveRightFunct;
};

function moveLeftFunct(){
	this.position.x-=2;
};

function moveRightFunct(){
	this.position.x+=2;
};

let myShip = new Ship([50,50], "myShip2.png")
let ship2 = new Ship([100, 100], "otherShip.png")

// Mostramos nuestras naves

// Ahora tenemos algo similar a un new de C# y Java, pero sigue faltando la herencia



