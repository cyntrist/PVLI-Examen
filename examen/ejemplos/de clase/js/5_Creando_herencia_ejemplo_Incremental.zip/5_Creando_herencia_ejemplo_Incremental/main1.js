/*
	Objeto "ship" con 2 propiedades (position, graphic) y 2 métodos (moveLeft y moveRight)
	moveLeft y moveRight son funciones que operan como métodos de nuestro objeto para
	cambiar su posición
*/
let ship = {
	position: {
		x:0, 
		y:0
	},
	graphic: "ship.png",
	moveLeft: function() {this.position.x-=2},
	moveRight: function() {this.position.x+=2}
};

let enemy = Object.create(ship); // Creamos el objeto enemy a partir del objeto ship (copiamos sus propiedades)
								 // esto es usar la cadena de prototipos para extender nuestra nave y crear "enemy"
//más info sobre Object.create() en https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Global_Objects/Object/create

enemy.advance = function() {this.position.y+=2}; //añadimos un nuevo método al objeto enemy
enemy.score = 100; //añadimos una nueva propiedad al objeto enemy

let ally = Object.create(ship); // Creamos el objeto ally a partir del objeto ship 

//Comprueba el valor de "enemy"
//Prueba enemy.moveLeft()
//Prueba enemy.advance()
//Vuelve a comprobar el valor de enemy

//Comprueba el valor de "ally"

//En la consola del navegador escribe enemy y fijate que tiene una propiedad <prototype>  --> cadena de prototypos

//¿Problemas?
//Cada vez que creamos un objeto nuevo no podemos elegir los valores de sus propiedades, tenemos que cambiarlas a posteriori