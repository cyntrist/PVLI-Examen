/**
 * Devuelve el texto "uooooo! Vaya alerta"
 * @returns {string}
 */
function devuelveTextoDeAlerta() {
  return "uooooo! Vaya alerta";
}

/**
 * Hace desaparecer el elemento con id nombre
 * @param {string} nombre 
 */
function desaparece(nombre) {
	var button = document.getElementById(nombre);
  button.style.visibility='hidden';
}