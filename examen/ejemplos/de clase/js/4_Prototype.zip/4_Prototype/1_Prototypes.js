/**
 * CADENA DE PROTOTIPOS - "heredar propiedades"
 * Más info: https://developer.mozilla.org/es/docs/Learn/JavaScript/Objects/Object_prototypes
 */
 
let obj3 = { f: "F" };

// Encadenamos obj2 a obj3
let obj2 = Object.create(obj3);
obj2.d = "D";
obj2.e = "E";

// Encadenamos obj1 a obj2
let obj1 = Object.create(obj2);
obj1.a = "A";
obj1.b = "B";
obj1.c = "C";

/* obj1 --> obj2 --> obj3 */

show(obj1.c); // muestra C --> obj1 tiene la propiedad c
show(obj1.d); // muestra D --> obj1 busca la propiedad d en su cadena de prototipos
show(obj1.f); // muestra F --> obj1 busca la propiedad f en su cadena de prototipos
show(obj1.z); // undefined 


/*
show(Object.getPrototypeOf(obj1));
show(Object.getPrototypeOf(obj2));
show(Object.getPrototypeOf(obj3));
show(Object.getPrototypeOf(Object.prototype));
*/

/*
show(obj1.hasOwnProperty('c'));
show(obj1.hasOwnProperty('d'));
show(obj1.hasOwnProperty('f'));
show(obj1.hasOwnProperty('z'));
*/

/*
show(obj2.hasOwnProperty('c'));
show(obj2.hasOwnProperty('d'));
show(obj2.hasOwnProperty('f'));
show(obj2.hasOwnProperty('z'));
*/

/*
show(obj3.hasOwnProperty('c'));
show(obj3.hasOwnProperty('d'));
show(obj3.hasOwnProperty('f'));
show(obj3.hasOwnProperty('z'));
*/

function show(toShow){
	console.log(toShow)
}