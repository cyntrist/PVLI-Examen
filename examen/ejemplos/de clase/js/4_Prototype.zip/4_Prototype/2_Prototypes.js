/**
 * CADENA DE PROTOTIPOS - "heredar propiedades"
 */
let myShow = function(){
	console.log("coordenates: ", this.x+","+this.y);
	console.log("affiliation: ", this.affiliation);
	console.log("armor: ", this.armor);
	console.log("weapon: ", this.weapon);
	console.log("cargo: ", this.cargo);
}

let ship = { x: 100, y: 50, showShip: myShow };

let enemyShip = Object.create(ship); //enemyShip tendrá las propiedades x, y, showShip ya que lo tendré en la cadena de prototipos
enemyShip.affiliation = "Enemy"; //además añadimos las propiedades affiliation y armor
enemyShip.armor = 100;

/*enemyDestroyer --> enemyShip --> ship*/
let enemyDestroyer = Object.create(enemyShip); //enemyDestroyer tendrá las propiedades x, y, showShip, affilitation y armor ya que lo tendré en la cadena de prototipos
enemyDestroyer.weapon = "Cannon"; //además añadimos las propied weapon

/*enemyCargoShip --> enemyShip --> ship*/
let enemyCargoShip = Object.create(enemyShip); //enemyCargoShip tendrá las propiedades x, y, showShip, affilitation y armor ya que lo tendré en la cadena de prototipos
enemyCargoShip.cargo = "25t"; //además añadimos la propiedad cargo


show(enemyDestroyer.x);
show(enemyDestroyer.y);
show(enemyDestroyer.armor)
show(enemyDestroyer.affiliation);
show(enemyDestroyer.weapon);
show(enemyDestroyer.cargo);


/*
enemyCargoShip.showShip()
console.log("----")
enemyDestroyer.showShip()
*/


/*
show(Object.getPrototypeOf(enemyDestroyer));
show(Object.getPrototypeOf(enemyShip));
show(Object.getPrototypeOf(ship));
show(Object.getPrototypeOf(Object.prototype));
*/

/*
show(enemyDestroyer.hasOwnProperty('armor'));
show(enemyDestroyer.hasOwnProperty('weapon'));
show(enemyDestroyer.hasOwnProperty('x'));
show(enemyDestroyer.hasOwnProperty('invent'));
*/

/*
show(enemyShip.hasOwnProperty('armor'));
show(enemyShip.hasOwnProperty('weapon'));
show(enemyShip.hasOwnProperty('x'));
show(enemyShip.hasOwnProperty('invent'));
*/

/*
show(ship.hasOwnProperty('armor'));
show(ship.hasOwnProperty('weapon'));
show(ship.hasOwnProperty('x'));
show(ship.hasOwnProperty('invent'));
*/

function show(toShow){
	console.log(toShow)
}
