let ship1 = { name: 'T-Fighter', method: inspect };
let ship2 = { name: 'X-Wing', method: inspect };
let onlyNameShip = { name: 'Death Star' };

function inspect() {
  // sólo inspecciona this
  console.log('Tipo:', typeof this);
  console.log('Valor:', this);
}

//inspect();

//ship1.method();

//ship2.method();

//inspect.apply(onlyNameShip); // hace que this valga onlyNameShip en inspect

//console.log(ship1.method === ship2.method)