/*
	Objeto que representa un enemigo
	Tiene los siguientes atributos:
		- _graphic - imagen que le representa
		- _currentDirection - dirección actual de movimiento
		- _position - objeto con parámetros x e y que representan la posición
		- _score - puntuación que se consigue al vencer al enemigo
	Además tiene los siguientes métodos:
		- _moveLeft - incrementa la posición x en 2 unidades
		- _moveRight - decrementa la posición x en 2 unidades
		- _advance - incrementa la posición y en 2 unidades
		- _shoot - "dispara"
*/
let enemy = {
  _graphic: 'specie01.png',
  _currentDirection: 'right',
  _position: { x: 10, y: 10 },
  _score: 40,

  moveLeft: function () { this._position.x -= 2; },
  moveRight: function () { this._position.x += 2; },
  advance: function () { this._position.y += 2; },
  shoot: function () { console.log('PICHIUM!'); } // (es un láser)
};

/*
	Objeto que representa una nave
	Tiene los siguientes atributos:
		- _graphic - imagen que le representa
		- _currentDirection - dirección actual de movimiento
		- _position - objeto con parámetros x e y que representan la posición
		- _score - puntuación que se consigue al vencer al enemigo
	Además tiene los siguientes métodos:
		- moveLeft - cogemos la función moveLeft del objeto enemy
		- moveRight - cogemos la función moveRight del objeto enemy
		- advance - cogemos la función advance del objeto enemy
		- shoot - cogemos la función shoot del objeto enemy
*/
let ship = {
  _graphic: 'myShip.png',
  _currentDirection: 'right',
  _position: { x: 0, y: 0 },
  _score: 40,

  moveLeft: enemy.moveLeft,
  moveRight: enemy.moveRight,
  advance: enemy.advance,
  shoot: enemy.shoot
}

console.log("------------------------");
console.log("enemy:", enemy); // fíjate en la posición
console.log("hacemos enemy.moveLeft())")
enemy.moveLeft();   // ""movemos"" al objeto enemy
console.log("enemy:", enemy); // fíjate en la posición otra vez
console.log("------------------------");


console.log("------------------------");
console.log("ship:", ship); // fíjate en la posición
console.log("hacemos ship.moveLeft())")
ship.moveLeft();
console.log("ship:", ship); // fíjate en la posición otra vez
console.log("------------------------");

/*
	ambos casos funcionan aunque en el objeto ship los métodos de movimiento son los del objeto enemy
	esto se debe a que estamos usando this, y este cambia según el objeto desde el que llamamos
	en el primer caso this será nuestro objeto enemy, pero en el segundo caso pasa a ser el objeto ship
*/
