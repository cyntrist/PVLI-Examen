/*
	diceUtils es una variable let (letiable) que guarda un objeto
	este objeto tiene 2 propiedades: history y newDie
	history es un Array
	newDie es una función que devuelve otra función
*/
let diceUtils = {
	history: [], // lleva el histórico de tiradas

	newDice: function (sides) {
		return function dice() {
			let result = Math.floor(Math.random() * sides) + 1;
			
			//console.log(result); //podéis comprobar que se genera un número aleatorio entre 1 y sides
			//console.log(this);   //podéis comprobar el valor de this
			
			//intentamos guardar en history el número generado pero this no será el objeto diceUtils por lo que no tiene una propiedad history
			this.history.push([new Date(), sides, result]); 
		}
	}
}

const d10 = diceUtils.newDice(10); 
//d10(); // dará error, como hemos dicho, this no será nuestro objeto diceUtils

d10.apply(diceUtils) // Esto sí funcionará, llamamos a d10() diciendo que el contexto, this, es diceUtils

// más info sobre apply() en https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Global_Objects/Function/apply