// newDice es una función que devolverá otra función a la cual podremos llamar más adelante
function newDice(sides) {
	return function () {
		return console.log(Math.floor(Math.random() * sides) + 1);
	};
}
var d100 = newDice(100); //d100 ahora guarda una función que devuelve "console.log(Math.floor(Math.random() * 100) + 1);"
var d20 = newDice(20);   //d20 ahora guarda una función que devuelve "console.log(Math.floor(Math.random() * 20) + 1);"

d100 !== d20; // d100 y d20 son distintas funciones (posiciones de memoria diferentes), son creadas en dos llamadas distintas a newDie

d100(); //genera un número del 1 al 100 
d20();  //genera un número del 1 al 20