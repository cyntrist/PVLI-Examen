/*
	variable objeto que tiene 4 propiedades:
		- cadena - variable que contiene la cadena "Soy String"
		- fun1 - función que devuelve cadena
		- fun2 - función que devuelve this.cadena
		- fun3 - función que devuelve otra función que devuelve this.cadena
		- fun4 - función que guarda this en self y devuelve otra función que devuelve self.cadena
*/
let objeto = {
	cadena: "Soy String",
	
	fun1: function(){
		return cadena
	},
	
	fun2: function(){
		return this.cadena
	},
	
	fun3: function(){
		return function(){
			return this.cadena
		}
	},
	
	fun4: function(){
		var self = this;
		return function(){
			return self.cadena
		}
	}
}

console.log(objeto.cadena) // muestra "soy string"
//console.log(objeto.fun1()) // no tenemos acceso a cadena
console.log(objeto.fun2()) // muestra "soy string"
//console.log(objeto.fun3()()) // el this no es nuestro objeto
console.log(objeto.fun4()()) // muestra "soy string" ya que antes hemos guardado el this que apunta a objeto en la variable self


function inspect() {
	console.log('Tipo:', typeof this)
	console.log('valor:', this)
}

let ship1 = { name: 'T-Fighter', method: inspect };
let ship2 = { name: 'X-Wing', method: inspect };
ship1.method(); // this es el Objeto ship1
ship2.method(); // this es el objeto ship2
inspect(); //this es el objeto global