/*
	diceUtils es una variable let (letiable) que guarda un objeto
	este objeto tiene 2 propiedades: history y newDie
	history es un Array
	newDie es una función que devuelve otra función
*/
let diceUtils = {
	history: [], // lleva el histórico de tiradas
	
	newDice: function (sides) {
		let self = this; // guardamos el this que tenemos en newDice en self ==> self es ahora el destinatario de newDie
		return function dice() {
			let result = Math.floor(Math.random() * sides) + 1;
			self.history.push([new Date(), sides, result]); //usamos self, en el que hemos guardado el this del objeto superior para no perderlo, y accedemos con el a history.
			
			console.log(result);
		}
	}
}

const d10 = diceUtils.newDice(10);
const d20 = diceUtils.newDice(20);
const d100 = diceUtils.newDice(100);

d10();
d20();
d100();
d10();
d10();

console.log(diceUtils.history); // muestra el historial de tiradas

/*
let fun = diceUtils.newDice; // referencia a la función desde una variable en la raiz del archivo
const d2_10 = fun(10)
d2_10() // esto da error, el objeto que guardamos en self ya no es diceUtils ya que la función se está llamando desde la raiz. 
		//El receptor del mensaje es el objeto global

*/