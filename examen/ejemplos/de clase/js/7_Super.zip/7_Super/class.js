/* 
	Cuando usamos herencia podemos acceder a los métodos del padre usando la palabra reservada super
	más info: https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Operators/super
*/

/**
 * Clase que representa una posición
 */
class Position{
	/**
	 * Crea una posición
	 * @param {number} x - El valor de la coordenada X.
	 * @param {number} y - El valor de la coordenada Y.
	 */
	constructor(x, y){
		this.x = x;
		this.y = y;
	}
}

/**
 * Clase que representa una nave
 * @extends Ship
 */
class Ship{
	/**
	 * Crea una nave
	 * @param {Position} position - La posición de la nave.
	 * @param {string} graphic - imagen que representa a la nave.
	 */
	constructor(position, graphic){
		this._position = position;
		this._graphic = graphic;
	}
	
	/**
	 * Mueve la nave a la izquierda
	 */
	moveLeft(){
		this._position.x-=2;
	}
	
	/**
	 * Mueve la nave a la derecha
	 */
	moveRight(){
		this._position.x+=2;
	}
};

/**
 * Clase que representa un enemigo, hereda de Ship
 * @extends Ship
 */
class Enemy extends Ship{
	/**
	 * Crea un enemigo
	 * @param {Position} position - La posición de la nave.
	 * @param {string} graphic - imagen que representa a la nave.
	 * @param {number} score - puntos que da al derrotarlo.
	 */
	constructor(position, graphic, score){
		super(position, graphic); // llamamos al contructor de Ship para conseguir sus atributos
		this._currentDirection = 'right';
		this._score = score;
	}
	
	/**
	 * Mueve la nave a la izquierda
	 * @override
	 */
	moveLeft(){
		super.moveLeft(); // Con estamos llamando al método moveLeft del padre (la cual hace this._position.x-=2)
		this._position.x-=5;
		// En total moveremos la nave 7 unidades
	}
	
	/**
	 * Mueve la nave a la derecha
	 * @override
	 */
	moveRight(){
		super.moveRight(); // Con estamos llamando al método moveLeft del padre (la cual hace this._position.x-=2)
		this._position.x+=5;
		// En total moveremos la nave 7 unidades
	}
	
	/**
	 * Mueve la nave hacia adelante
	 */
	advance(){
		this._position.y += 2;
	}
}

/**
 * Clase que representa al jugador, hereda de Ship
 * @extends Ship
 */
class Ally extends Ship{
	/**
	 * Crea una nave de jugador
	 * @param {Position} position - La posición de la nave.
	 */
	constructor(position){
		super(position, "ally.png") // llamamos al contructor de Ship para conseguir sus atributos
	}
	
	/**
	 * Mueve la nave a la izquierda
	 * @override
	 */
	moveLeft(){
		console.log("averiado")
		// Como nos llamamos igual que el método padre y no llamamos a super.moveLeft estamos "sobrescribendo" el método
		// Solo nos ejecutaremos nosotros, y al hacer .moveLeft de un objeto Ally se mostrará el mensaje "averiado" y no cambiará su posición
	}
	
	/**
	 * Mueve la nave a la derecha
	 * @override
	 */
	moveRight(){
		console.log("averiado")
		// Como nos llamamos igual que el método padre y no llamamos a super.moveRight estamos "sobrescribendo" el método
		// Solo nos ejecutaremos nosotros, y al hacer .moveLeft de un objeto Ally se mostrará el mensaje "averiado" y no cambiará su posición
	}
}



//Instanciación de objetos
let me = new Ally(new Position(0,0));
let enemy = new Enemy(new Position(100, 100), "enemy1.png", 666);
let ship = new Ship(new Position(50,50), "myShip2.png")


// Prueba los métodos moveLeft() y moveRight() de los objetos me, enemy y ship
