/*
	letiable obj que contiene un objeto con 3 parámetros (pares clave-valor)
	Más info: https://developer.mozilla.org/es/docs/Learn/JavaScript/Objects/Basics
*/
let obj = {
	a: 2, // propiedad a con valor 2
	b: { c: 5 }, // propiedad b con un objeto que tiene una propiedad c con valor 5
	d: function(){ return 9 } // propiedad d que contiene una función que devuelve el valor 9
}

console.log(obj.a) //muestra 2, estámos accediendo a la propiedad a de nuestra variable obj
console.log(obj["a"]) //muestra 2, ésta es otra de acceder a la propiedad de un objeto
console.log(obj.b.c) // muestra 5, podemos acceder a las propiedades de objetos "hijos"
console.log(obj.d()) // muestra 9, los objetos pueden contener funciones, y las podemos llamar