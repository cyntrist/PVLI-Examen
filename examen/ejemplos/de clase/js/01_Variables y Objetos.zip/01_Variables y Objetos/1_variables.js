
// Podemos llamar a las funciones al inicio del programa debido al hoisting
// https://developer.mozilla.org/es/docs/Glossary/Hoisting

letFunction();
varFunction();
constFunction();
nopFunction();

/**
 * 	función para comprobar el comportamiento de los letiables
 *	más info: https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Statements/let
 */
function letFunction() {
	console.log("letFunction");
	let a = 5;
	var b = 9;
	
	console.log(a); // muestra 5
	
	if (a < b)
	{
		let a = 3; // este letiable opaca al del ambito superior, pero solo en el if, fuera de este se destruirá
		let c = 6;
		console.log(a); // muestra 3
	}
	
	console.log(a); // muestra 5	
	//console.log(c); // da error, c solo está definido dentro del if
}

/*
	función para probar el comportamiento de las variables
	más info: https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Statements/var
*/
function varFunction() {
	console.log("varFunction");
	var a = 5;
	var b = 9;
	
	console.log(a); // muestra 5
	
	if (a < b)
	{
		var a = 3; // hemos redefinido var dentro de g()
		var c = 1;
	}
	 
	console.log(a); // muestra 3, lo hemos redefinido en el if, pero al ser var se comporta de manera global
	
	for(c; c< 10; c++); 

	console.log(c); // muestra 10, lo hemos incrementado con el for
}

/*
	función para probar el comportamiento de las constantes
	https://developer.mozilla.org/es/docs/Web/JavaScript/Reference/Statements/const
*/
function constFunction() {
	console.log("constFunction");
	const a = 5;
	
	console.log(a); // muestra 5

	if(true){
		const b = 3;
	}

	//console.log(b); // da error, los const tienen el mismo comportamiento en cuanto a ámbito que los let 
	
	//a = 6;		// da error, no podemos dar otro valor a una constante
	//var a = 6; 	// da error, no podemos redefinir una constante
}

/*
	función para probar el comportamiento de las variables no declaradaas, no indicamos si son var, let o const
*/
function nopFunction(){
	console.log("nopFunction");
	z = 10;

	console.log(z); // muestra 10

	if (true){
		z = 3;
		console.log(z); // muestra 3
	}

	console.log(z); // muestra 3
}
console.log(z); // si no indicamos tipo de variable, esta sera globar a nivel de archivo.
//console.log(x); // da error, var es global a nivel de funciones, pero no de archivo.
